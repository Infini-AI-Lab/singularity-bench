"""Sealed pure-Python FA4 package; no CUDA extension import."""
